const Usuario = require('./usuario');
const Categoria = require('./categoria');

module.exports = {
    Usuario,
    Categoria
}