const express = require('express');
const router = express.Router();

const usuarioController = require('../controllers/UsuarioControllers');
router.post('/login', usuarioController.login);

module.exports = router;