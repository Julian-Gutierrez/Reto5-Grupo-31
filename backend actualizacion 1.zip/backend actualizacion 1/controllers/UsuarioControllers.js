//const {model} = require('mongoose');
const models = require('../models');
const bcrypt = require('bcrypt');

module.exports = {
    login: async(req, res, next) =>{
        try {
            let user = await models.Usuario.findOne({
                correo: req.body.correo,
                estado: 1
            });
            if (user) {
                let match = await bcrypt.compare(req.body.password, user.password);
                if (match) {
                    console.log(user);
                    res.status(200).json({user});
                }else{
                    res.status(401).send({
                        message: "password incorrect!"
                    })
                }
                
            } else {
                res.status(404).send({
                    message: "user not found!"
                })
            }
            
        } catch (error) {
            res.status(500).send({
                message: "error!"
            })
            next(error);
        }
    }
}